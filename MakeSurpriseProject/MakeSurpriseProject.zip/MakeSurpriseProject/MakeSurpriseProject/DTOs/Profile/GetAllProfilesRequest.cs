﻿namespace MakeSurpriseProject.DTOs.Profile
{
    public class GetAllProfilesRequest
    {
        public int UserId { get; set; }

        public bool? UserRelativeType { get; set; }
    }
}
