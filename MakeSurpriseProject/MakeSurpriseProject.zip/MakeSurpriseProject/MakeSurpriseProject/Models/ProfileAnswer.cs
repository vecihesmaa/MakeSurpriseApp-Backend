﻿namespace MakeSurpriseProject.Models
{
    public class ProfileAnswer
    {
        public int FirstQuestionAnswer { get; set; }

        public int SecondQuestionAnswer { get; set; }

        public int ThirdQuestionAnswer { get; set; }

        public int FourthQuestionAnswer { get; set; }

        public int FifthQuestionAnswer { get; set; }

        public int SixthQuestionAnswer { get; set; }

        public int SeventhQuestionAnswer { get; set; }

        public int EighthQuestionAnswer { get; set; }

        public int NinthQuestionAnswer { get; set; }

        public int TenthQuestionAnswer { get; set; }

        public int EleventhQuestionAnswer { get; set; }

        public int TwelfthQuestionAnswer { get; set; }

        public int ThirteenthQuestionAnswer { get; set; }

        public int FourteenthQuestionAnswer { get; set; }

        public int FifteenthQuestionAnswer { get; set; }
    }
}
