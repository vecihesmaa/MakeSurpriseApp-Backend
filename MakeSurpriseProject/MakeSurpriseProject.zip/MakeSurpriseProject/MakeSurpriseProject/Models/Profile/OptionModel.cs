﻿namespace MakeSurpriseProject.Models.Profile
{
    public class OptionModel
    {
        public int OptionId { get; set; }
        public string OptionText { get; set; }
    }
}
