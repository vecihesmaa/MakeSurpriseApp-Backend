﻿using MakeSurpriseProject.Contexts;
using MakeSurpriseProject.Entities;
using Microsoft.EntityFrameworkCore;

namespace MakeSurpriseProject.Services
{
    public class CargoService
    {
        private readonly MakeSurpriseDbContext context;
        public CargoService(MakeSurpriseDbContext _context)
        {
            context = _context;
        }

        public async Task<List<OrderItem>> GetAllCargosAsync(int userId)
        {
            var orderItems = await context.OrderItems
                .Where(o => o.UserRelative.UserId == userId)
                .Include(o => o.Cargos)
                .Include(o => o.Address)
                    .ThenInclude(a => a.Province)       
                .Include(o => o.Address)
                    .ThenInclude(a => a.District)      
                .Include(o => o.Address)
                    .ThenInclude(a => a.Neighbourhood) 
                .Include(o => o.UserRelative)
                .ToListAsync();

            return orderItems;
        }
    }
}
