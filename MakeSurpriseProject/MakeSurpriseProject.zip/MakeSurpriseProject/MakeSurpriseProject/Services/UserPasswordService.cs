﻿using MakeSurpriseProject.Contexts;
using MakeSurpriseProject.DTOs.UserProfile;
using Microsoft.EntityFrameworkCore;

namespace MakeSurpriseProject.Services
{
    public class UserPasswordService
    {
        private readonly MakeSurpriseDbContext context;
        public UserPasswordService(MakeSurpriseDbContext _context)
        {
            context = _context;
        }
    
        public async Task<bool> IsPasswordRegisteredAsync(UserPasswordManagementRequest userPasswordManagement)
        {   
            return await context.Users.AnyAsync(user => user.UserId == userPasswordManagement.UserId && user.Password == userPasswordManagement.OldPassword);
        }

        public async Task<bool> ChangePasswordAsync(UserPasswordManagementRequest userPasswordManagement)
        {
            var user = await context.Users.FirstOrDefaultAsync(user => user.UserId == userPasswordManagement.UserId);
            if (user is not null) {
                user.Password = userPasswordManagement.NewPassword;
                await context.SaveChangesAsync();
                return true;
            }
            return false;
        }
    }
}
