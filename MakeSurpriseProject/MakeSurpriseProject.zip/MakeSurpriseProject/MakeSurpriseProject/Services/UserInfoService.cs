﻿using MakeSurpriseProject.Contexts;
using MakeSurpriseProject.DTOs.UserProfile;
using MakeSurpriseProject.Entities;
using Microsoft.EntityFrameworkCore;

namespace MakeSurpriseProject.Services
{
    public class UserInfoService
    {
        private readonly MakeSurpriseDbContext context;
        public UserInfoService(MakeSurpriseDbContext _context) {
            context = _context;
        }

        public async Task<UserInfoResponse> GetUserInfoAsync(int userId)
        {
            var userInfo = await context.Users
                                      .Where(u => u.UserId == userId)
                                      .Select( u => new UserInfoResponse
                                      {
                                          FirstName = u.FirstName,
                                          LastName = u.LastName,
                                          PhoneNumber =  u.UserProfiles.FirstOrDefault().PhoneNumber
                                      })
                                      .FirstOrDefaultAsync();

            return userInfo;
        }

        public async Task<bool> ChangeUserInfoAsync(UserInfoRequest userInfo)
        {
            var user = await context.Users.FirstOrDefaultAsync(user => user.UserId == userInfo.UserId);
            if (user is not null)
            {
                var userProfile = await context.UserProfiles.FirstOrDefaultAsync(userProfile => userProfile.UserId == user.UserId);
                if (userProfile is null)
                {
                    userProfile = new UserProfile()
                    {
                        UserId = userInfo.UserId,
                    };
                    await context.UserProfiles.AddAsync(userProfile);
                }
                user.FirstName = userInfo.FirstName;
                user.LastName = userInfo.LastName;
                userProfile.PhoneNumber = userInfo.PhoneNumber;
                await context.SaveChangesAsync();
                return true;

            }
            return false;
        }
    }
}
