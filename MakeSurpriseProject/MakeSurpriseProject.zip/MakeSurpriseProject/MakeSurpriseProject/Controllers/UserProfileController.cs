﻿using MakeSurpriseProject.DTOs.UserProfile;
using MakeSurpriseProject.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace MakeSurpriseProject.Controllers
{
    public class UserProfileController : Controller
    {
        private readonly CargoService cargoService;
        private readonly UserPasswordService userPasswordService;
        private readonly UserInfoService userInfoService;

        public UserProfileController(CargoService _cargoService, UserPasswordService _userPasswordService, UserInfoService _userInfoService)
        {
            cargoService = _cargoService;
            userPasswordService = _userPasswordService;
            userInfoService = _userInfoService;
        }
        public async Task<IActionResult> GetAllCargos(int userId)
        {
            var orderItems = await cargoService.GetAllCargosAsync(userId);
            return Ok(orderItems);
        }

        [HttpPost]
        public async Task<IActionResult> PasswordManagement([FromBody] UserPasswordManagementRequest userPasswordManagement)
        {
            var isPasswordRegistered = await userPasswordService.IsPasswordRegisteredAsync(userPasswordManagement);
            if (isPasswordRegistered)
            {
                var isSucceedChangePassword = await userPasswordService.ChangePasswordAsync(userPasswordManagement);
                if (isSucceedChangePassword)
                {
                    return Ok("");
                }
            }
            return BadRequest();
        }

        public async Task<IActionResult> GetUserInfo(int userId)
        {
            var userInfo = await userInfoService.GetUserInfoAsync(userId);
            return Ok(userInfo);
        }

        [HttpPost]
        public async Task<IActionResult> ChangeUserInfo([FromBody] UserInfoRequest userInfo)
        {
            var isSucceedChangeUserInfo = await userInfoService.ChangeUserInfoAsync(userInfo);
            if (isSucceedChangeUserInfo)
            {
                return Ok();
            }
            return BadRequest();
        }
    }
}
